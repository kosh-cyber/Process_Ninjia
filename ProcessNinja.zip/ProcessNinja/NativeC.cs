﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using static ProcessNinja.Flag;
using static ProcessNinja.Struct;
using Microsoft.Win32.SafeHandles;

namespace ProcessNinja
{
    class NativeC
    {
        public static class userenv {
            [DllImport("userenv.dll", SetLastError = true)]
            public static extern bool CreateEnvironmentBlock(out IntPtr lpEnvironment,
            IntPtr hToken,
            bool bInherit);
        }
        public static class kernel32 
        {
            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern uint ResumeThread(IntPtr hThread);

            [DllImport("kernel32.dll")]
            public static extern Boolean VirtualProtectEx(
            IntPtr hProcess,
            IntPtr lpAddress,
            UInt32 dwSize,
            AllocationProtect flNewProtect,
            ref UInt32 lpflOldProtect);

            [DllImport("kernel32.dll")]
            public static extern Boolean WriteProcessMemory(
            IntPtr hProcess,
            IntPtr lpBaseAddress,
            IntPtr lpBuffer,
            UInt32 nSize,
            ref UInt32 lpNumberOfBytesWritten);

            [DllImport("kernel32.dll")]
            public static extern IntPtr VirtualAllocEx(
            IntPtr hProcess,
            IntPtr lpAddress,
            uint dwSize,
            int flAllocationType,
            int flProtect);

            [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
            public static extern IntPtr CreateFileW(
            [MarshalAs(UnmanagedType.LPWStr)] string filename,
            [MarshalAs(UnmanagedType.U4)] EFileAccess access,
            [MarshalAs(UnmanagedType.U4)] EFileShare share,
            IntPtr securityAttributes,
            [MarshalAs(UnmanagedType.U4)] EFileMode creationDisposition,
            [MarshalAs(UnmanagedType.U4)] EFileAttributes flagsAndAttributes,
            IntPtr templateFile);

            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern bool ReadFile(
            IntPtr hFile,
            [Out] byte[] lpBuffer,
            uint nNumberOfBytesToRead,
            out uint lpNumberOfBytesRead,
            IntPtr lpOverlapped);

            [DllImport("kernel32.dll")]
            public static extern bool WriteFile(
            [In] IntPtr hFile,
            [In]  byte[] lpBuffer,
            [In] uint nNumberOfBytesToWrite,
            [Out,Optional] out uint lpNumberOfBytesWritten,
            [In, Out, Optional] ref System.Threading.NativeOverlapped lpOverlapped);

            [DllImport("kernel32.dll", SetLastError = true)]
            public static extern bool SetFileInformationByHandle(IntPtr hFile,
            FileInformationClass FileInformationClass,
            ref FILE_DISPOSITION_INFO FileInformation,
            Int32 dwBufferSize);

            [DllImport("Kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
            public static extern uint SetFilePointer(
            [In] SafeFileHandle hFile,
            [In] int lDistanceToMove,
            [Out] out int lpDistanceToMoveHigh,
            [In] EMoveMethod dwMoveMethod);

        }
        public static class ntdll {
            [DllImport("ntdll.dll", SetLastError = true, ExactSpelling = true)]
            public static extern UInt32 NtCreateSection(
            ref IntPtr SectionHandle,
            UInt32 DesiredAccess,
            IntPtr ObjectAttributes,
            ref UInt32 MaximumSize,
            UInt32 SectionPageProtection,
            UInt32 AllocationAttributes,
            IntPtr FileHandle);

            [DllImport("ntdll.dll")]
            public static extern int NtCreateProcessEx(
            ref IntPtr ProcessHandle,
            UInt32 DesiredAccess,
            IntPtr ObjectAttributes,
            IntPtr hInheritFromProcess,
            uint Flags,
            IntPtr SectionHandle,
            IntPtr DebugPort,
            IntPtr ExceptionPort,
            Byte InJob);

            [DllImport("ntdll.dll", SetLastError = true)]
            public static extern int NtQueryInformationProcess(IntPtr hProcess,
            int ProcessInfoClass,
            out PROCESS_BASIC_INFORMATION pbi,
            int cb,
            out long pSize);

            [DllImport("ntdll.dll", SetLastError = true)]
            public static extern uint NtReadVirtualMemory(IntPtr ProcessHandle,
            IntPtr BaseAddress,
            byte[] Buffer,
            UInt32 NumberOfBytesToRead,
            ref UInt32 NumberOfBytesRead);

            [DllImport("ntdll.dll", ExactSpelling = true, SetLastError = false)]
            public static extern int NtClose(IntPtr hObject);

            [DllImport("ntdll.dll", SetLastError = true)]
            public static extern uint NtCreateThreadEx(ref IntPtr threadHandle,
            UInt32 desiredAccess,
            IntPtr objectAttributes,
            IntPtr processHandle,
            IntPtr startAddress,
            IntPtr parameter,
            bool inCreateSuspended,
            Int32 stackZeroBits,
            Int32 sizeOfStack,
            Int32 maximumStackSize,
            IntPtr attributeList);

            [DllImport("ntdll.dll")]
            public static extern UInt32 RtlCreateProcessParametersEx(
            ref IntPtr pProcessParameters,
            IntPtr ImagePathName,
            IntPtr DllPath,
            IntPtr CurrentDirectory,
            IntPtr CommandLine,
            IntPtr Environment,
            IntPtr WindowTitle,
            IntPtr DesktopInfo,
            IntPtr ShellInfo,
            IntPtr RuntimeData,
            uint Flags);

            //https://github.com/n1xbyte/Toolkit/blob/69c24f8cdd898f20ac3a79e81cc6bb61de8fa197/C%23%20Stuff/ProcessDopplegang.cs
        }


    }
}
