﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using static ProcessNinja.Flag;

namespace ProcessNinja
{
    class Struct
    {
        [StructLayout(LayoutKind.Sequential)]
        public struct FILE_DISPOSITION_INFO
        {
            public bool DeleteFile;
        }


        [StructLayout(LayoutKind.Sequential)]
        public struct PROCESS_BASIC_INFORMATION
        {
            //public NtStatus ExitStatus;
            public uint ExitStatus;
            public IntPtr PebBaseAddress;
            public UIntPtr AffinityMask;
            public int BasePriority;
            public UIntPtr UniqueProcessId;
            public UIntPtr InheritedFromUniqueProcessId;
        }

        [StructLayout(LayoutKind.Explicit, Size = 0x40)]
        public struct PEB
        {
            [FieldOffset(0x000)]
            public byte InheritedAddressSpace;
            [FieldOffset(0x001)]
            public byte ReadImageFileExecOptions;
            [FieldOffset(0x002)]
            public byte BeingDebugged;
            [FieldOffset(0x003)]
            public byte Spare;
            [FieldOffset(0x008)]
            public IntPtr Mutant;
            [FieldOffset(0x010)]
            public IntPtr ImageBaseAddress;     // (PVOID) 
            [FieldOffset(0x018)]
            public IntPtr Ldr;                  // (PPEB_LDR_DATA)
            [FieldOffset(0x020)]
            public IntPtr ProcessParameters;    // (PRTL_USER_PROCESS_PARAMETERS)
            [FieldOffset(0x028)]
            public IntPtr SubSystemData;        // (PVOID) 
            [FieldOffset(0x030)]
            public IntPtr ProcessHeap;          // (PVOID) 
            [FieldOffset(0x038)]
            public IntPtr FastPebLock;          // (PRTL_CRITICAL_SECTION)
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct UnicodeString
        {
            public ushort Length;
            public ushort MaximumLength;
            public IntPtr Buffer;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct UnicodeString64
        {
            public ushort Length;
            public ushort MaximumLength;
            public UInt32 __padding;
            public UInt64 Buffer;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct RtlUserProcessParameters
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            public byte[] Reserved1;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
            public IntPtr[] Reserved2;
            public UnicodeString ImagePathName;
            public UnicodeString CommandLine;
            public IntPtr Environment;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
            public IntPtr[] Reserved3; // StartingPositionLeft, -Top, Width, Height, CharWidth, -Height, ConsoleTextAttributes, WindowFlags, ShowWindowFlags
            public UnicodeString WindowTitle;
            public UnicodeString DesktopName;
            public UnicodeString ShellInfo;
            public UnicodeString RuntimeData;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32 * 4)]
            public IntPtr[] Reserved4;
            public uint EnvironmentSize;
        }
        //https://stackoverflow.com/questions/5470698/read-environment-variables-from-a-process-in-c-sharp
        [StructLayout(LayoutKind.Sequential)]
        public struct RtlUserProcessParameters64
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            public byte[] Reserved1;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
            public IntPtr[] Reserved2;
            public UnicodeString64 CurrentDirectoryPath;
            public UnicodeString64 DllPath;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            public IntPtr[] Reserved2b;
            public UnicodeString64 ImagePathName;
            public UnicodeString64 CommandLine;
            public UInt64 Environment;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 9)]
            public IntPtr[] Reserved3; // StartingPositionLeft, -Top, Width, Height, CharWidth, -Height, ConsoleTextAttributes, WindowFlags, ShowWindowFlags
            public UnicodeString64 WindowTitle;
            public UnicodeString64 DesktopName;
            public UnicodeString64 ShellInfo;
            public UnicodeString64 RuntimeData;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32 * 6)]
            public IntPtr[] Reserved4;
            public uint EnvironmentSize;
        }

    }
}
