﻿using System;
using System.Text;
using System.Runtime.InteropServices;
using static ProcessNinja.NativeC;
using static ProcessNinja.Flag;
using static ProcessNinja.Struct;

namespace ProcessNinja
{
    class Function
    {
        public static IntPtr FetchPEB(IntPtr hProcess)
        {
            PROCESS_BASIC_INFORMATION pbi = new PROCESS_BASIC_INFORMATION();
            long pSize;
            ntdll.NtQueryInformationProcess(hProcess, 0x00, out pbi, Marshal.SizeOf(pbi), out pSize);
            byte[] pebBytes = new byte[0x40];
            uint numRead = 0;
            ntdll.NtReadVirtualMemory(hProcess, pbi.PebBaseAddress, pebBytes, (uint)pebBytes.Length, ref numRead);

            GCHandle pPEB = GCHandle.Alloc(pebBytes, GCHandleType.Pinned);
            PEB peb = (PEB)Marshal.PtrToStructure(pPEB.AddrOfPinnedObject(), typeof(PEB));

            return peb.ImageBaseAddress;
        }
        public static PROCESS_BASIC_INFORMATION PBI(IntPtr hProc)
        {
            PROCESS_BASIC_INFORMATION PBI = new PROCESS_BASIC_INFORMATION();
            int PBI_Size = Marshal.SizeOf(PBI);
            long RetLen = 0;
            ntdll.NtQueryInformationProcess(hProc, 0, out PBI, PBI_Size, out RetLen);
            return PBI;
        }

        public static IntPtr EmitUnicodeString(String Data)
        {
            UnicodeString StringObject = new UnicodeString();
            StringObject.Length = (UInt16)(Data.Length * 2);
            StringObject.MaximumLength = (UInt16)(StringObject.Length + 1);
            StringObject.Buffer = Marshal.StringToHGlobalUni(Data);
            IntPtr pUnicodeString = Marshal.AllocHGlobal(16);
            Marshal.StructureToPtr(StringObject, pUnicodeString, true);
            return pUnicodeString;
        }

        public static Boolean WriteRemoteMem(IntPtr hProc, IntPtr param, AllocationProtect Protect)
        {

            return true;
        }

        public static bool SetupProcessParameters(IntPtr hProcess, string targetPath)
        {

            string WinDir = Environment.GetEnvironmentVariable("windir");
            IntPtr uSystemDir = EmitUnicodeString((WinDir + "\\System32"));
            IntPtr uLaunchPath = EmitUnicodeString(targetPath);
            IntPtr uWindowName = EmitUnicodeString("");
            IntPtr environment = IntPtr.Zero;
            //CreateEnvironmentBlock(out environment, IntPtr.Zero, true);

            IntPtr pProcessParams = IntPtr.Zero;
            uint RtlCreateSuccess = ntdll.RtlCreateProcessParametersEx(
                ref pProcessParams,
                uLaunchPath, 
                uSystemDir, 
                uSystemDir, 
                uLaunchPath, 
                environment, 
                uWindowName, 
                IntPtr.Zero, 
                IntPtr.Zero, 
                IntPtr.Zero,
                1 // #define RTL_USER_PROC_PARAMS_NORMALIZED 0x00000001
                );
            if (RtlCreateSuccess != 0)
            {
                Console.WriteLine("[!] Failed to create process parameters");
                return false;
            }
            else
            {
                Console.WriteLine("[+] RtlCreateProcessParametersEx success!");
            }

            RtlUserProcessParameters64 test = (RtlUserProcessParameters64)Marshal.PtrToStructure(pProcessParams, typeof(RtlUserProcessParameters64));
            Console.WriteLine(test.EnvironmentSize);
            Console.WriteLine(test.CommandLine);



            return true;
        }
    }
}
